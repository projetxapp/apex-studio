import React, { useState, useEffect } from "react";

// ─── API ───────────────────────────────────────────
function repairJSON(str) {
  let s = str.trim();
  s = s.replace(/,\s*"[^"]*"\s*:\s*"[^"]*$/, '');
  s = s.replace(/,\s*"[^"]*"\s*:\s*\d*$/, '');
  s = s.replace(/,\s*"[^"]*"\s*$/, '');
  s = s.replace(/,\s*\{[^}]*$/, '');
  const opens   = (s.match(/\{/g)||[]).length - (s.match(/\}/g)||[]).length;
  const openArr = (s.match(/\[/g)||[]).length - (s.match(/\]/g)||[]).length;
  for(let i=0;i<openArr;i++) s+=']';
  for(let i=0;i<opens;i++)   s+='}';
  return JSON.parse(s);
}
async function callClaude(prompt) {
  const res = await fetch("/api/claude", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:prompt}]})
  });
  const env = JSON.parse(await res.text());
  if(env.error) throw new Error(env.error.message||JSON.stringify(env.error));
  const text = env.content?.[0]?.text||"";
  const m = text.match(/\{[\s\S]*\}/);
  if(!m) throw new Error("Pas de JSON dans la réponse");
  try { return JSON.parse(m[0]); } catch(e) { return repairJSON(m[0]); }
}


// ─── PERSISTANCE LOCALE ────────────────────────────
function saveToStorage(key, value) {
  try { localStorage.setItem('apex_' + key, JSON.stringify(value)); } catch(e) {}
}
function loadFromStorage(key, fallback = null) {
  try {
    const v = localStorage.getItem('apex_' + key);
    return v ? JSON.parse(v) : fallback;
  } catch(e) { return fallback; }
}

// ─── PERSONAS ──────────────────────────────────────
const JORDAN = `Tu es Jordan, ex-Partner Sequoia Capital, 500+ startups analysées, 30 licornes sourcées. Tu cherches UNIQUEMENT des apps IA-first où l'IA donne un avantage décisif et où les solutions actuelles sont objectivement mauvaises. Tu rates jamais un gap de marché. Raisonne avant de répondre. Prends des initiatives.`;
const SOFIA  = `Tu es Sofia, ex-McKinsey senior, 200+ analyses Fortune 500. Données concrètes, risques cachés, projections réalistes. Raisonne étape par étape. Prends des initiatives : signale ce que le fondateur sous-estime.`;
const MARCUS = `Tu es Marcus, ex-Stripe ex-Airbnb, 20 ans PM, 40 apps lancées dont 12 à 100k+ users. Tu penses en systèmes. Raisonne étape par étape. Prends des initiatives : dis ce que le fondateur ne voit pas.`;
const LEO    = `Tu es Leo, ex-Head of Growth Spotify, expert ASO mondial, 200+ fiches App Store optimisées, 3 apps montées à 1M+ téléchargements grâce à l'ASO. Tu connais les algorithmes App Store et Play Store mieux que personne. Chaque mot compte.`;
const MAYA   = `Tu es Maya, ex-CMO d'une licorne SaaS (exit $400M), spécialiste growth marketing et content. Tu as lancé 50+ campagnes virales. Tu sais exactement quoi dire, à qui, sur quel canal, pour convertir. Tes posts LinkedIn font 100k vues.`;

// ─── PROMPTS JORDAN ────────────────────────────────
const P_SCAN = () => `${JORDAN}
Analyse le marché global des apps mobiles et web en 2025. Identifie les 5 secteurs qui ont le PLUS BESOIN d'une app IA innovante RIGHT NOW.
Critères: secteur sous-digitalisé OU mal servi OU où l'IA peut remplacer un process manuel douloureux.
Textes courts (6 mots max). JSON brut: {"secteurs":[{"nom":"Nom du secteur","emoji":"🎯","pourquoi":"pourquoi ce secteur a besoin d'IA","douleur":"douleur principale des utilisateurs","gap":"ce qui manque vraiment","score":90,"exemples_nuls":"apps existantes nulles"}]}`;

const P_IDEAS = (s) => `${JORDAN}
Secteur: "${s}". Trouve 2 idées d'apps IA-FIRST innovantes.

RÈGLES STRICTES:
1. L'IA doit être au CŒUR du produit (pas juste un chatbot collé)
2. Les solutions actuelles doivent être objectivement mauvaises - dis pourquoi précisément
3. 100% no-code (Bubble/Glide/Make/Softr/Brevo/Stripe)
4. Coût infra < 100€/mois
5. Rentable avec 50 clients payants
6. Textes COURTS (6 mots max par champ)

JSON brut: {"apps":[{"nom":"Nom","emoji":"🚀","tagline":"6 mots","gap":"pourquoi les solutions actuelles sont nulles","ia_advantage":"en quoi l'IA change tout ici","preuve":"preuve demande existe","outil":"outils no-code","infra":"€X/mois","clients":50,"prix":"€X/mois","score":85,"diff":"Facile","conseil":"conseil clé"}]} diff=Facile/Moyen/Difficile`;

// ─── PROMPTS SOFIA ─────────────────────────────────
const P_MARCHE = (n,s,j) => {
  const jc = j ? `\nJordan: gap="${j.gap||""}" ia="${j.ia_advantage||""}" outil="${j.outil_nocode||""}"` : "";
  return `${SOFIA}\nApp "${n}" secteur "${s}".${jc}\nAnalyse marché. Creuse plus loin que Jordan. Textes concis. JSON brut: {"taille":"€X","croissance":"X%/an","public":"cible précise","pain":"douleur réelle","concurrent1":"nom+faiblesse","concurrent2":"nom+faiblesse","gap":"opportunité creusée","timing":"pourquoi maintenant","risque":"risque caché","conseil":"initiative Sofia"}`;
};
const P_BUSINESS = (n,s,j,m) => {
  const jc = j ? `\nJordan: prix="${j.prix_client||""}" clients=${j.clients_pour_rentable||""}` : "";
  const mc = m ? `\nSofia marché: taille="${m.taille||""}" public="${m.public||""}"` : "";
  return `${SOFIA}\nApp "${n}" secteur "${s}".${jc}${mc}\nModèle éco réaliste. JSON brut: {"modele":"type","gratuit":"offre free","premium":"€X/mois+avantages","cac":"€X","ltv":"€X","an1":"€X","an3":"€X","monetisation":"mécanisme","erreur":"erreur classique fondateurs","conseil":"initiative Sofia"}`;
};
const P_ROADMAP = (n,s,j) => { const jc=j?" Outil Jordan: "+(j.outil_nocode||""):"" ; return `${SOFIA}\nApp "${n}" secteur "${s}".${jc}\nRoadmap réaliste. JSON brut: {"features":["f1","f2","f3"],"delai":"X sem","front":"outil","back":"outil","ia_tool":"outil IA si besoin","cout":"€X","dette":"problème no-code LT","e1":"étape 1","e2":"étape 2","e3":"étape 3","conseil":"raccourci Sofia"}`;; }
const P_GTM = (n,s,j) => { const jc=j?" Prix: "+(j.prix_client||""):"" ; return `${SOFIA}\nApp "${n}" secteur "${s}".${jc}\nStratégie lancement. JSON brut: {"c1":"canal+tactique","c2":"canal+tactique","users":"100 premiers","kpi1":"métrique","kpi2":"métrique","budget":"€X","m1":"objectif mois 1","m6":"objectif 6 mois","pivot":"quand changer","action":"action demain matin","conseil":"conseil Sofia"}`;; }

// ─── PROMPTS MARCUS ────────────────────────────────
const P_VISION  = (n,s,ctx) => {
  const j  = ctx?.jordan  ? `\nJordan: gap="${ctx.jordan.gap||""}" ia="${ctx.jordan.ia_advantage||""}"` : "";
  const sm = ctx?.sofia?.marche   ? `\nSofia: taille="${ctx.sofia.marche.taille||""}" public="${ctx.sofia.marche.public||""}"` : "";
  const sb = ctx?.sofia?.business ? ` modèle="${ctx.sofia.business.modele||""}" an1="${ctx.sofia.business.an1||""}"` : "";
  return `${MARCUS}\nApp "${n}" secteur "${s}".${j}${sm}${sb}\nVision produit cohérente avec contexte. JSON brut: {"oneliner":"pitch 1 phrase","probleme":"2 phrases","fait":["f1","f2","f3","f4"],"pasfait":["np1","np2","np3"],"user1":"persona précis","user2":"persona 2","risque1":"risque 1","risque2":"risque 2","wow":"feature wow","conseil":"initiative Marcus"}`;
};
const P_SCREENS = (n,s,c) => `${MARCUS}\nApp "${n}" secteur "${s}". Ctx: ${c}\nÉcrans UX. JSON brut: {"onboarding":["é1","é2","é3"],"core":["é1","é2","é3","é4"],"cta":"action principale","retention":"mécanisme retour","antipattern":"erreur UX à éviter","conseil":"amélioration non évidente"}`;
const P_LOGIC   = (n,s,c) => `${MARCUS}\nApp "${n}" secteur "${s}". Ctx: ${c}\nLogique métier. JSON brut: {"entites":["e1+champs","e2","e3"],"regles":["r1","r2","r3","r4"],"autos":["trigger→action1","trigger→action2","trigger→action3"],"apis":["api1+pourquoi","api2"],"conseil":"optimisation tech non évidente"}`;
const P_NOCODE  = (n,s,c) => `${MARCUS}\nApp "${n}" secteur "${s}". Ctx: ${c}\nStack no-code. JSON brut: {"principal":"outil+pourquoi","db":"outil","auth":"comment","paiement":"Stripe+comment","notifs":"service","ia":"outil IA","workflows":["w1","w2"],"cout":"€X/mois","mvp":"X semaines","piege":"piège absolu à éviter"}`;
const P_LAUNCH  = (n,s,c) => `${MARCUS}\nApp "${n}" secteur "${s}". Ctx: ${c}\nLancement. JSON brut: {"inclus":["f1","f2","f3"],"exclu":["f1","f2"],"validation":"tester avant de construire","premiers":"stratégie 100 users","s1":"KPI sem1","m1":"KPI mois1","m3":"KPI mois3","pivot":"quand pivoter","demain":"action 9h demain","conseil":"conseil Marcus"}`;

// ─── PROMPTS LEO (ASO) ─────────────────────────────
const P_ASO_STORE = (n,s,desc,cible) => `${LEO}\nApp: "${n}" | Secteur: "${s}" | Description: "${desc}" | Cible: "${cible}"\nGénère la fiche App Store / Play Store parfaite. Optimisée pour l'algorithme ET la conversion. JSON brut: {"titre":"30 car max avec mot-clé principal","sous_titre":"30 car max accrocheur","description_courte":"80 car elevator pitch","description_longue":"500 car persuasive avec mots-clés","keywords":["kw1","kw2","kw3","kw4","kw5","kw6","kw7"],"categorie":"catégorie principale","categorie2":"catégorie secondaire","screenshots":["screen1 description+texte overlay","screen2","screen3","screen4","screen5"],"conseil_leo":"l'erreur ASO que tous les devs font"}`;
const P_ASO_NOTES = (n,notes_actuelles) => `${LEO}\nApp: "${n}" | Notes actuelles: ${notes_actuelles}/5\nStratégie pour améliorer les notes et reviews. JSON brut: {"strategie_reviews":"comment obtenir des 5 étoiles","moment_demande":"quand demander une review","message_demande":"texte exact à afficher","reponse_mauvaise_note":"template réponse 1-2 étoiles","a_b_test":"quel élément tester en premier pour améliorer conversion","conseil_leo":"hack ASO que personne ne connaît"}`;

// ─── PROMPTS MAYA (MARKETING) ──────────────────────
const P_CONTENT_STRATEGY = (n,s,cible) => `${MAYA}\nApp: "${n}" | Secteur: "${s}" | Cible: "${cible}"\nStratégie de contenu complète. JSON brut: {"positionnement":"comment se différencier sur les réseaux","ton":"style de communication","canal1":"canal principal+pourquoi","canal2":"canal secondaire","canal3":"canal tertiaire","hook_types":["type de hook 1","type 2","type 3"],"contenu_pilier1":"sujet pilier 1","contenu_pilier2":"sujet pilier 2","contenu_pilier3":"sujet pilier 3","conseil_maya":"insight marketing non évident"}`;
const P_POSTS = (n,s,cible) => `${MAYA}\nApp: "${n}" | Secteur: "${s}" | Cible: "${cible}"\nGénère 3 posts LinkedIn viraux prêts à publier. Chaque post doit avoir un hook ultra-fort, de la valeur, un CTA. JSON brut: {"post1":{"hook":"première ligne qui arrête le scroll","corps":"contenu du post (4-6 paragraphes courts)","cta":"appel à l'action","hashtags":["h1","h2","h3"]},"post2":{"hook":"...","corps":"...","cta":"...","hashtags":["h1","h2","h3"]},"post3":{"hook":"...","corps":"...","cta":"...","hashtags":["h1","h2","h3"]},"conseil_maya":"ce qui rend un post viral dans ce secteur"}`;
const P_CALENDAR = (n,s) => `${MAYA}\nApp: "${n}" | Secteur: "${s}"\nCalendrier éditorial 4 semaines. JSON brut: {"s1":["lundi: sujet","mercredi: sujet","vendredi: sujet"],"s2":["lundi: sujet","mercredi: sujet","vendredi: sujet"],"s3":["lundi: sujet","mercredi: sujet","vendredi: sujet"],"s4":["lundi: sujet","mercredi: sujet","vendredi: sujet"],"format_gagnant":"format de contenu qui performe le mieux dans ce secteur","conseil_maya":"timing optimal de publication"}`;

// ─── ÉTAPES ────────────────────────────────────────
const R_STEPS = [{key:"marche",label:"Analyse marché",emoji:"📊"},{key:"business",label:"Modèle éco",emoji:"💰"},{key:"roadmap",label:"Roadmap",emoji:"🛠️"},{key:"gtm",label:"Lancement",emoji:"🚀"}];
const S_STEPS = [{key:"vision",label:"Vision",emoji:"🎯"},{key:"screens",label:"Écrans",emoji:"📱"},{key:"logic",label:"Logique",emoji:"⚙️"},{key:"nocode",label:"No-Code",emoji:"🛠️"},{key:"launch",label:"Lancement",emoji:"🚀"}];
const A_STEPS = [{key:"store",label:"Fiche store",emoji:"📱"},{key:"reviews",label:"Stratégie notes",emoji:"⭐"}];
const M_STEPS = [{key:"strategy",label:"Stratégie contenu",emoji:"🎯"},{key:"posts",label:"3 posts LinkedIn",emoji:"✍️"},{key:"calendar",label:"Calendrier 4 sem",emoji:"📅"}];

// ─── UI PARTAGÉS ───────────────────────────────────
function Block({title,accent,children}){return <div style={{background:"white",borderRadius:16,padding:"18px 20px",marginBottom:12,boxShadow:"0 2px 10px rgba(0,0,0,.06)",borderLeft:"3px solid "+accent}}><div style={{fontWeight:800,fontSize:13,color:"#1a1a2e",marginBottom:10,paddingBottom:7,borderBottom:"1px solid #f5f5f5"}}>{title}</div>{children}</div>;}
function G2({children,mb}){return <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:mb||8}}>{children}</div>;}
function IB({label,children,bg,full}){return <div style={{background:bg||"#f8f8ff",borderRadius:10,padding:"10px 12px",marginBottom:full?7:0}}><div style={{fontSize:8,fontWeight:700,color:"#aaa",letterSpacing:1,marginBottom:3,textTransform:"uppercase"}}>{label}</div><div style={{fontSize:11,color:"#333",lineHeight:"1.5"}}>{children||"—"}</div></div>;}
function LB({label,items,color,bg}){return <div style={{background:bg||"#f8f8ff",borderRadius:10,padding:"10px 12px",marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#aaa",letterSpacing:1,marginBottom:6,textTransform:"uppercase"}}>{label}</div>{(items||[]).map((it,i)=><div key={i} style={{display:"flex",gap:5,marginBottom:3}}><span style={{color,fontWeight:700,flexShrink:0}}>→</span><span style={{fontSize:11,color:"#333",lineHeight:"1.4"}}>{it}</span></div>)}</div>;}
function Init({label,children,color}){return <div style={{background:"#faf5ff",borderLeft:"3px solid "+(color||"#7c3aed"),borderRadius:10,padding:"10px 12px",marginBottom:7}}><div style={{fontSize:8,fontWeight:700,color:color||"#7c3aed",letterSpacing:1,marginBottom:4,textTransform:"uppercase"}}>💡 {label}</div><div style={{fontSize:11,color:"#4c1d95",lineHeight:"1.5"}}>{children}</div></div>;}
function Conseil({children,c1,c2,label}){const bg="linear-gradient(135deg,"+(c1||"#7c3aed")+","+(c2||"#4f46e5")+")";return <div style={{background:bg,borderRadius:12,padding:"14px 16px"}}><div style={{fontSize:8,fontWeight:700,color:"rgba(255,255,255,.6)",letterSpacing:1,marginBottom:5,textTransform:"uppercase"}}>{label||"Conseil"}</div><div style={{fontSize:13,fontWeight:600,color:"white",lineHeight:"1.5",fontStyle:"italic"}}>"{children}"</div></div>;}
function StepBar({steps,current,done,loading}){
  return <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:16}}>{steps.map((s,i)=>{
    const d=!!done[s.key]; const a=i===current&&loading;
    const bg=d?"#f5f3ff":a?"#ede9fe":"#f9f9f9";
    const border=d?"1px solid #c4b5fd":a?"1px solid #a78bfa":"1px solid #f0f0f0";
    const cbg=d?"#7c3aed":a?"linear-gradient(135deg,#7c3aed,#4f46e5)":"#e5e7eb";
    const cc=(d||a)?"white":"#9ca3af"; const tc=d?"#5b21b6":a?"#4c1d95":"#9ca3af"; const sc=d?"#a78bfa":a?"#7c3aed":"#d1d5db";
    return <div key={s.key} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 13px",borderRadius:10,background:bg,border:border,transition:"all .3s"}}>
      <div style={{width:24,height:24,borderRadius:"50%",background:cbg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:cc,flexShrink:0,fontWeight:700}}>{d?"✓":a?"~":String(i+1)}</div>
      <div style={{flex:1}}><div style={{fontWeight:600,fontSize:12,color:tc}}>{s.emoji} {s.label}</div><div style={{fontSize:9,color:sc}}>{d?"Terminé":a?"En cours...":"En attente"}</div></div>
    </div>;
  })}</div>;
}
function ErrBox({msg}){return msg?<div style={{background:"#fff5f5",border:"1px solid #fecaca",borderRadius:12,padding:"12px 16px",marginBottom:12,fontSize:11,color:"#7f1d1d",fontFamily:"monospace",wordBreak:"break-all"}}>{msg}</div>:null;}
function Loading({emoji,text,sub}){return <div style={{background:"white",borderRadius:14,padding:"36px",textAlign:"center",boxShadow:"0 2px 12px rgba(0,0,0,.07)"}}><div style={{fontSize:40,animation:"spin 2s linear infinite",display:"inline-block",marginBottom:12}}>{emoji}</div><div style={{fontWeight:700,color:"#1a1a2e",marginBottom:4}}>{text}</div><div style={{color:"#aaa",fontSize:12}}>{sub}</div></div>;}
function ExportBtn({onClick,label,c1,c2}){const bg="linear-gradient(135deg,"+(c1||"#7c3aed")+","+(c2||"#4f46e5")+")";return <button onClick={onClick} style={{background:bg,border:"none",borderRadius:10,padding:"11px 20px",fontSize:12,color:"white",cursor:"pointer",fontFamily:"inherit",fontWeight:700}}>{label}</button>;}
function ResetBtn({onClick}){return <button onClick={onClick} style={{background:"white",border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 16px",fontSize:12,fontWeight:600,color:"#555",cursor:"pointer",fontFamily:"inherit"}}>← Nouveau</button>;}
function PostCard({post,i,accent}){
  if(!post) return null;
  return <div style={{background:"white",borderRadius:14,padding:"16px 18px",marginBottom:12,boxShadow:"0 2px 10px rgba(0,0,0,.06)",borderLeft:"3px solid "+accent}}>
    <div style={{fontSize:8,fontWeight:700,color:"#aaa",letterSpacing:1,marginBottom:8,textTransform:"uppercase"}}>Post {i+1}</div>
    <div style={{background:"#fef9c3",borderRadius:8,padding:"8px 11px",marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#854d0e",marginBottom:3,textTransform:"uppercase"}}>Hook (1ère ligne)</div><div style={{fontSize:13,fontWeight:700,color:"#1a1a2e"}}>{post.hook}</div></div>
    <div style={{background:"#f8f8ff",borderRadius:8,padding:"8px 11px",marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#aaa",marginBottom:3,textTransform:"uppercase"}}>Corps</div><div style={{fontSize:11,color:"#444",lineHeight:"1.6",whiteSpace:"pre-line"}}>{post.corps}</div></div>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",flexWrap:"wrap",gap:6}}>
      <div style={{background:"#f0fdf4",borderRadius:8,padding:"6px 10px",flex:1}}><div style={{fontSize:8,fontWeight:700,color:"#15803d",marginBottom:2,textTransform:"uppercase"}}>CTA</div><div style={{fontSize:11,color:"#15803d",fontWeight:600}}>{post.cta}</div></div>
      <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>{(post.hashtags||[]).map((h,j)=><span key={j} style={{background:"#eff6ff",color:"#1d4ed8",borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:500}}>#{h}</span>)}</div>
    </div>
  </div>;
}

// ─── AGENT 1 : JORDAN ──────────────────────────────
function AgentIdeation({onSelectApp}) {
  const [mode,     setMode]     = useState("home");
  const [secteur,  setSecteur]  = useState("");
  const [loading,  setLoading]  = useState(false);
  const [scan,     setScan]     = useState(null);
  const [concepts, setConcepts] = useState(null);
  const [err,      setErr]      = useState(null);

  async function runScan() {
    setLoading(true); setErr(null); setScan(null); setMode("scanning");
    try { const d=await callClaude(P_SCAN()); setScan(d.secteurs||[]); setMode("scan_done"); }
    catch(e) { setErr(e.message); setMode("home"); }
    setLoading(false);
  }
  async function runIdeas(s) {
    const sec=s||secteur; if(!sec.trim()||loading) return;
    setLoading(true); setErr(null); setConcepts(null); setMode("analyzing");
    try { const d=await callClaude(P_IDEAS(sec)); setConcepts(d.apps||[]); setMode("ideas_done"); }
    catch(e) { setErr(e.message); setMode("home"); }
    setLoading(false);
  }

  const DIFF={"Facile":{bg:"#d1fae5",c:"#065f46"},"Moyen":{bg:"#fef3c7",c:"#92400e"},"Difficile":{bg:"#fee2e2",c:"#991b1b"}};
  const GRADS=["linear-gradient(135deg,#667eea,#764ba2)","linear-gradient(135deg,#f093fb,#f5576c)"];

  return <div>
    <div style={{background:"linear-gradient(135deg,#667eea,#764ba2)",borderRadius:16,padding:"20px",marginBottom:16}}>
      <div style={{fontSize:28,marginBottom:6}}>🔍</div>
      <div style={{fontWeight:900,fontSize:18,color:"white",marginBottom:3}}>Jordan — Agent Idéation</div>
      <div style={{fontSize:12,color:"rgba(255,255,255,.7)"}}>Ex-Partner Sequoia · IA-first apps only · Gaps que personne ne voit</div>
    </div>
    <ErrBox msg={err}/>

    {(mode==="home"||mode==="scan_done"||mode==="ideas_done") && <div style={{background:"white",borderRadius:14,padding:18,boxShadow:"0 2px 12px rgba(0,0,0,.07)",marginBottom:16}}>
      <div style={{display:"flex",gap:8,marginBottom:12,flexWrap:"wrap"}}>
        <input value={secteur} onChange={e=>setSecteur(e.target.value)} onKeyDown={e=>e.key==="Enter"&&runIdeas()} placeholder="Ex: football, immobilier, RH…" style={{flex:1,minWidth:150,border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#667eea"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <button onClick={()=>runIdeas()} disabled={loading||!secteur.trim()} style={{padding:"11px 20px",background:loading||!secteur.trim()?"#e9e9e9":"linear-gradient(135deg,#667eea,#764ba2)",color:loading||!secteur.trim()?"#aaa":"white",border:"none",borderRadius:10,fontSize:13,fontWeight:700,cursor:loading||!secteur.trim()?"not-allowed":"pointer",whiteSpace:"nowrap"}}>Analyser ✨</button>
      </div>
      <button onClick={runScan} disabled={loading} style={{width:"100%",padding:"12px",background:"linear-gradient(135deg,#fef3c7,#fde68a)",border:"1px solid #f59e0b",borderRadius:10,fontSize:13,fontWeight:700,color:"#92400e",cursor:"pointer",fontFamily:"inherit",marginBottom:8}}>
        🌍 Scan opportunités — Jordan analyse le marché global pour toi
      </button>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
        {["Football","Santé mentale","Logistique","Beauté","Seniors","Agriculture","Juridique","BTP"].map(s=><button key={s} onClick={()=>runIdeas(s)} style={{background:"#f8f8ff",border:"1px solid #eaeaf8",borderRadius:16,padding:"4px 11px",fontSize:11,cursor:"pointer",color:"#666",fontFamily:"inherit"}} onMouseEnter={e=>{e.target.style.background="#ede9fe";e.target.style.color="#5b21b6";}} onMouseLeave={e=>{e.target.style.background="#f8f8ff";e.target.style.color="#666";}}>{s}</button>)}
      </div>
    </div>}

    {mode==="scanning" && <Loading emoji="🌍" text="Jordan scanne le marché global..." sub="Identification des 5 meilleures opportunités IA"/>}
    {mode==="analyzing" && <Loading emoji="🔍" text={"Jordan analyse le secteur « "+secteur+" »..."} sub="Recherche des gaps IA non exploités"/>}

    {mode==="scan_done" && scan && <div style={{animation:"fadeUp .4s ease-out"}}>
      <div style={{fontWeight:700,fontSize:13,color:"#555",marginBottom:10}}>🌍 Top 5 secteurs qui ont besoin d'IA — clique pour explorer</div>
      {scan.map((s,i)=><div key={i} onClick={()=>{setSecteur(s.nom);runIdeas(s.nom);}} style={{background:"white",borderRadius:14,padding:"14px 18px",marginBottom:10,boxShadow:"0 2px 12px rgba(0,0,0,.07)",cursor:"pointer",display:"flex",alignItems:"center",gap:12,transition:"all .2s"}} onMouseEnter={e=>e.currentTarget.style.boxShadow="0 6px 24px rgba(0,0,0,.12)"} onMouseLeave={e=>e.currentTarget.style.boxShadow="0 2px 12px rgba(0,0,0,.07)"}>
        <div style={{fontSize:28,flexShrink:0}}>{s.emoji}</div>
        <div style={{flex:1}}>
          <div style={{fontWeight:800,fontSize:14,color:"#1a1a2e",marginBottom:2}}>{s.nom}</div>
          <div style={{fontSize:11,color:"#888",marginBottom:4}}>{s.douleur}</div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            <span style={{background:"#ede9fe",color:"#5b21b6",borderRadius:6,padding:"2px 8px",fontSize:10,fontWeight:600}}>Gap: {s.gap}</span>
            <span style={{background:"#fff8f0",color:"#92400e",borderRadius:6,padding:"2px 8px",fontSize:10}}>Nuls: {s.exemples_nuls}</span>
          </div>
        </div>
        <div style={{background:"linear-gradient(135deg,#667eea,#764ba2)",borderRadius:10,padding:"8px 12px",textAlign:"center",flexShrink:0}}>
          <div style={{fontSize:20,fontWeight:900,color:"white",lineHeight:1}}>{s.score}</div>
          <div style={{fontSize:7,color:"rgba(255,255,255,.7)"}}>SCORE</div>
        </div>
      </div>)}
    </div>}

    {mode==="ideas_done" && concepts && <div style={{animation:"fadeUp .4s ease-out"}}>
      <div style={{fontWeight:700,fontSize:13,color:"#555",marginBottom:10}}>2 apps IA-first — clique pour rapport complet</div>
      {concepts.map((app,i)=>{
        const badge=DIFF[app.diff]||DIFF[app.difficulte]||{bg:"#f0f0f0",c:"#555"};
        return <div key={i} style={{background:"white",borderRadius:16,overflow:"hidden",boxShadow:"0 3px 16px rgba(0,0,0,.08)",marginBottom:12,cursor:"pointer",transition:"all .2s"}} onClick={()=>onSelectApp&&onSelectApp(app,secteur)} onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-2px)";e.currentTarget.style.boxShadow="0 8px 28px rgba(0,0,0,.13)";}} onMouseLeave={e=>{e.currentTarget.style.transform="translateY(0)";e.currentTarget.style.boxShadow="0 3px 16px rgba(0,0,0,.08)";}}>
          <div style={{background:GRADS[i%2],padding:"16px 20px",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
            <div style={{flex:1}}><div style={{fontSize:24,marginBottom:4}}>{app.emoji}</div><div style={{fontWeight:900,fontSize:18,color:"white",marginBottom:2}}>{app.nom}</div><div style={{color:"rgba(255,255,255,.8)",fontSize:11,fontStyle:"italic"}}>"{app.tagline}"</div></div>
            <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:6,marginLeft:10}}>
              <div style={{background:"rgba(255,255,255,.2)",borderRadius:8,padding:"6px 10px",textAlign:"center"}}><div style={{fontSize:20,fontWeight:900,color:"white",lineHeight:1}}>{app.score||85}</div><div style={{fontSize:7,color:"rgba(255,255,255,.7)"}}>SCORE</div></div>
              <span style={{background:badge.bg,color:badge.c,borderRadius:6,padding:"2px 8px",fontSize:10,fontWeight:700}}>{app.diff||app.difficulte||"Moyen"}</span>
            </div>
          </div>
          <div style={{padding:"14px 20px"}}>
            <G2 mb={8}><IB label="🔍 Gap (pourquoi les concurrents sont nuls)" bg="#fff8f0">{app.gap}</IB><IB label="🤖 Avantage IA décisif" bg="#f0f4ff">{app.ia_advantage||app.ia_avantage}</IB></G2>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:8}}>
              <span style={{background:"#ede9fe",color:"#5b21b6",borderRadius:6,padding:"3px 9px",fontSize:10,fontWeight:600}}>🛠 {app.outil}</span>
              <span style={{background:"#fef9c3",color:"#854d0e",borderRadius:6,padding:"3px 9px",fontSize:10,fontWeight:600}}>💸 {app.infra}</span>
              <span style={{background:"#dcfce7",color:"#15803d",borderRadius:6,padding:"3px 9px",fontSize:10,fontWeight:600}}>🎯 {app.clients} clients × {app.prix}</span>
            </div>
            {app.conseil && <Init label="Initiative Jordan" color="#667eea">{app.conseil}</Init>}
            <div style={{textAlign:"right"}}><span style={{fontSize:12,fontWeight:700,color:"#667eea"}}>Rapport + Specs →</span></div>
          </div>
        </div>;
      })}
    </div>}
  </div>;
}

// ─── AGENT 2 : SOFIA ───────────────────────────────
function AgentRapport({prefill,onGoToSpecs}) {
  const [appName,setAppName]=useState(prefill?.nom||"");
  const [secteur,setSecteur]=useState(prefill?.secteur||"");
  const [phase,setPhase]=useState("idle");
  const [data,setData]=useState({});
  const [step,setStep]=useState(0);
  const [loading,setLoading]=useState(false);

  async function run(n,s){
    const name=n||appName; const sec=s||secteur;
    if(!name.trim()||!sec.trim()||loading) return;
    setLoading(true); setData({}); setStep(0); setPhase("gen");
    const full={}; const j=prefill?.jordan||null;
    for(let i=0;i<R_STEPS.length;i++){
      setStep(i);
      try{
        const k=R_STEPS[i].key;
        const prompt=k==="marche"?P_MARCHE(name,sec,j):k==="business"?P_BUSINESS(name,sec,j,full.marche||null):k==="roadmap"?P_ROADMAP(name,sec,j):P_GTM(name,sec,j);
        full[k]=await callClaude(prompt);
      }catch(e){full[R_STEPS[i].key]={_err:e.message};}
      setData({...full});
    }
    setPhase("done"); setLoading(false);
  }

  function exportMD(){
    const d=data; let md=`# RAPPORT — ${appName}\nSecteur: ${secteur}\n\n`;
    if(d.marche)  md+=`## Marché\n- Taille: ${d.marche.taille} | Croissance: ${d.marche.croissance}\n- Public: ${d.marche.public}\n- Concurrents: ${d.marche.concurrent1} / ${d.marche.concurrent2}\n- Gap: ${d.marche.gap} | Timing: ${d.marche.timing}\n- Risque: ${d.marche.risque} | 💡 ${d.marche.conseil}\n\n`;
    if(d.business)md+=`## Business\n- Modèle: ${d.business.modele} | Premium: ${d.business.premium}\n- CAC: ${d.business.cac} | LTV: ${d.business.ltv}\n- An1: ${d.business.an1} | An3: ${d.business.an3}\n- Erreur classique: ${d.business.erreur} | 💡 ${d.business.conseil}\n\n`;
    if(d.roadmap) md+=`## Roadmap\n- Features: ${(d.roadmap.features||[]).join(", ")}\n- Délai: ${d.roadmap.delai} | Coût: ${d.roadmap.cout}\n- Dette: ${d.roadmap.dette} | 💡 ${d.roadmap.conseil}\n\n`;
    if(d.gtm)     md+=`## Lancement\n- Canaux: ${d.gtm.c1} / ${d.gtm.c2}\n- 100 premiers: ${d.gtm.users}\n- Action demain: ${d.gtm.action}\n- 💬 ${d.gtm.conseil}\n`;
    const blob=new Blob([md],{type:"text/markdown"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a"); a.href=url; a.download="RAPPORT_"+appName.replace(/\s+/g,"_")+".md"; a.click(); URL.revokeObjectURL(url);
  }

  return <div>
    <div style={{background:"linear-gradient(135deg,#f093fb,#f5576c)",borderRadius:16,padding:"20px",marginBottom:16}}>
      <div style={{fontSize:28,marginBottom:6}}>📊</div>
      <div style={{fontWeight:900,fontSize:18,color:"white",marginBottom:3}}>Sofia — Agent Rapport</div>
      <div style={{fontSize:12,color:"rgba(255,255,255,.7)"}}>Ex-McKinsey · 200+ analyses · Fortune 500</div>
    </div>
    {phase==="idle"&&<div style={{background:"white",borderRadius:14,padding:18,boxShadow:"0 2px 12px rgba(0,0,0,.07)",marginBottom:16}}>
      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        <input value={appName} onChange={e=>setAppName(e.target.value)} placeholder="Nom de l'app" style={{flex:1,minWidth:130,border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#f093fb"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <input value={secteur} onChange={e=>setSecteur(e.target.value)} onKeyDown={e=>e.key==="Enter"&&run()} placeholder="Secteur" style={{flex:1,minWidth:130,border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#f093fb"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <button onClick={()=>run()} disabled={loading||!appName.trim()||!secteur.trim()} style={{padding:"11px 20px",background:!appName.trim()||!secteur.trim()?"#e9e9e9":"linear-gradient(135deg,#f093fb,#f5576c)",color:!appName.trim()||!secteur.trim()?"#aaa":"white",border:"none",borderRadius:10,fontSize:13,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}}>Analyser ✨</button>
      </div>
      {prefill?.jordan&&<div style={{marginTop:10,background:"#f0fff4",borderRadius:10,padding:"8px 12px",fontSize:11,color:"#15803d"}}>✅ Contexte Jordan chargé — gap: "{(prefill.jordan.gap||"").slice(0,40)}..."</div>}
    </div>}
    {phase==="gen"&&<StepBar steps={R_STEPS} current={step} done={data} loading={loading}/>}
    {phase==="done"&&<div style={{animation:"fadeUp .4s ease-out"}}>
      {data.marche&&!data.marche._err&&<Block title="📊 Analyse du marché" accent="#f093fb">
        <G2><IB label="Taille" bg="#fdf4ff">{data.marche.taille}</IB><IB label="Croissance" bg="#fdf4ff">{data.marche.croissance}</IB></G2>
        <G2><IB label="Public" bg="#f8f8ff">{data.marche.public}</IB><IB label="Pain point" bg="#f8f8ff">{data.marche.pain}</IB></G2>
        <G2><IB label="Concurrent 1" bg="#fff5f5">{data.marche.concurrent1}</IB><IB label="Concurrent 2" bg="#fff5f5">{data.marche.concurrent2}</IB></G2>
        <IB label="Gap" bg="#f0fff4" full>{data.marche.gap}</IB>
        <IB label="Risque caché" bg="#fff8f0" full>{data.marche.risque}</IB>
        <Init label="Initiative Sofia" color="#f5576c">{data.marche.conseil}</Init>
      </Block>}
      {data.business&&!data.business._err&&<Block title="💰 Modèle économique" accent="#f5576c">
        <G2><IB label="Modèle" bg="#fdf4ff">{data.business.modele}</IB><IB label="Premium" bg="#fdf4ff">{data.business.premium}</IB></G2>
        <G2><IB label="CAC" bg="#faf5ff">{data.business.cac}</IB><IB label="LTV" bg="#faf5ff">{data.business.ltv}</IB></G2>
        <G2><IB label="An 1" bg="#f0fdf4">{data.business.an1}</IB><IB label="An 3" bg="#f0fdf4">{data.business.an3}</IB></G2>
        <IB label="Erreur classique" bg="#fff8f0" full>{data.business.erreur}</IB>
        <Init label="Initiative Sofia" color="#f5576c">{data.business.conseil}</Init>
      </Block>}
      {data.roadmap&&!data.roadmap._err&&<Block title="🛠️ Roadmap" accent="#4facfe">
        <G2><IB label="Délai MVP" bg="#f0f9ff">{data.roadmap.delai}</IB><IB label="Coût MVP" bg="#faf5ff">{data.roadmap.cout}</IB></G2>
        <LB label="Features MVP" items={data.roadmap.features} color="#1d4ed8" bg="#eff6ff"/>
        <IB label="Dette technique" bg="#fff8f0" full>{data.roadmap.dette}</IB>
        <Init label="Initiative Sofia" color="#f5576c">{data.roadmap.conseil}</Init>
      </Block>}
      {data.gtm&&!data.gtm._err&&<Block title="🚀 Lancement" accent="#f5576c">
        <G2><IB label="Canal 1" bg="#f0f9ff">{data.gtm.c1}</IB><IB label="Canal 2" bg="#f0f9ff">{data.gtm.c2}</IB></G2>
        <IB label="100 premiers users" bg="#f0fff4" full>{data.gtm.users}</IB>
        <G2><IB label="KPI M1" bg="#faf5ff">{data.gtm.kpi1}</IB><IB label="KPI M3" bg="#faf5ff">{data.gtm.kpi2}</IB></G2>
        <div style={{background:"#fee2e2",borderRadius:10,padding:"11px 13px",marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#991b1b",letterSpacing:1,marginBottom:4,textTransform:"uppercase"}}>Action demain matin</div><div style={{fontSize:12,fontWeight:700,color:"#7f1d1d"}}>{data.gtm.action}</div></div>
        <Conseil c1="#f5576c" c2="#f093fb" label="Conseil Sofia">{data.gtm.conseil}</Conseil>
      </Block>}
      <div style={{display:"flex",gap:8,justifyContent:"center",marginTop:12,flexWrap:"wrap"}}>
        <ExportBtn onClick={exportMD} label="Télécharger .md" c1="#f093fb" c2="#f5576c"/>
        {onGoToSpecs&&<ExportBtn onClick={()=>onGoToSpecs(data)} label="Specs avec Marcus →" c1="#7c3aed" c2="#4f46e5"/>}
        <ResetBtn onClick={()=>{setPhase("idle");setData({});}}/>
      </div>
    </div>}
  </div>;
}

// ─── AGENT 3 : MARCUS ──────────────────────────────
function AgentSpecs({prefill}) {
  const [appName,setAppName]=useState(prefill?.nom||"");
  const [secteur,setSecteur]=useState(prefill?.secteur||"");
  const [phase,setPhase]=useState("idle");
  const [data,setData]=useState({});
  const [step,setStep]=useState(0);
  const [loading,setLoading]=useState(false);

  async function run(n,s){
    const name=n||appName; const sec=s||secteur;
    if(!name.trim()||!sec.trim()||loading) return;
    setLoading(true); setData({}); setStep(0); setPhase("gen");
    const full={};
    function buildCtx(res){
      let c="App:"+name+" Secteur:"+sec;
      if(prefill?.jordan) c+=" | Jordan:gap="+( prefill.jordan.gap||"")+",ia="+(prefill.jordan.ia_advantage||"");
      if(prefill?.sofia?.marche) c+=" | Sofia:taille="+(prefill.sofia.marche.taille||"")+",public="+(prefill.sofia.marche.public||"");
      if(prefill?.sofia?.business) c+=" | Modèle="+(prefill.sofia.business.modele||"")+",an1="+(prefill.sofia.business.an1||"");
      Object.keys(res).forEach(k=>{c+=" | M-"+k+":"+JSON.stringify(res[k]).slice(0,50);});
      return c;
    }
    for(let i=0;i<S_STEPS.length;i++){
      setStep(i);
      try{
        const ctx=buildCtx(full); const k=S_STEPS[i].key;
        const prompt=k==="vision"?P_VISION(name,sec,prefill):k==="screens"?P_SCREENS(name,sec,ctx):k==="logic"?P_LOGIC(name,sec,ctx):k==="nocode"?P_NOCODE(name,sec,ctx):P_LAUNCH(name,sec,ctx);
        full[k]=await callClaude(prompt);
      }catch(e){full[S_STEPS[i].key]={_err:e.message};}
      setData({...full});
    }
    setPhase("done"); setLoading(false);
  }

  function exportMD(){
    const d=data; let md="# SPECS — "+appName+"\n\n";
    if(d.vision) md+="## Vision\n"+d.vision.oneliner+"\n"+d.vision.probleme+"\nFait: "+(d.vision.fait||[]).join(", ")+"\nWow: "+d.vision.wow+"\n Conseil: "+d.vision.conseil+"\n\n";
    if(d.screens) md+="## Écrans\nOnboarding: "+(d.screens.onboarding||[]).join(" > ")+"\nCore: "+(d.screens.core||[]).join(", ")+"\nRétention: "+d.screens.retention+"\n\n";
    if(d.logic) md+="## Logique\nEntités: "+(d.logic.entites||[]).join(", ")+"\nRègles: "+(d.logic.regles||[]).join(" | ")+"\n\n";
    if(d.nocode) md+="## No-Code\n"+d.nocode.principal+"\nCoût: "+d.nocode.cout+" | MVP: "+d.nocode.mvp+"\nPiège: "+d.nocode.piege+"\n\n";
    if(d.launch) md+="## Lancement\nMVP: "+(d.launch.inclus||[]).join(", ")+"\nAction demain: "+d.launch.demain+"\nConseil: "+d.launch.conseil;
    const blob=new Blob([md],{type:"text/markdown"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a"); a.href=url; a.download="SPECS_"+appName.replace(/\s+/g,"_")+".md"; a.click(); URL.revokeObjectURL(url);
  }

  return <div>
    <div style={{background:"linear-gradient(135deg,#7c3aed,#4f46e5)",borderRadius:16,padding:"20px",marginBottom:16}}>
      <div style={{fontSize:28,marginBottom:6}}>📋</div>
      <div style={{fontWeight:900,fontSize:18,color:"white",marginBottom:3}}>Marcus — Agent Specs</div>
      <div style={{fontSize:12,color:"rgba(255,255,255,.7)"}}>Ex-Stripe, ex-Airbnb · 20 ans PM · 40 apps lancées</div>
    </div>
    {phase==="idle"&&<div style={{background:"white",borderRadius:14,padding:18,boxShadow:"0 2px 12px rgba(0,0,0,.07)",marginBottom:16}}>
      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        <input value={appName} onChange={e=>setAppName(e.target.value)} placeholder="Nom de l'app" style={{flex:1,minWidth:130,border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#7c3aed"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <input value={secteur} onChange={e=>setSecteur(e.target.value)} onKeyDown={e=>e.key==="Enter"&&run()} placeholder="Secteur" style={{flex:1,minWidth:130,border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#7c3aed"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <button onClick={()=>run()} disabled={loading||!appName.trim()||!secteur.trim()} style={{padding:"11px 20px",background:!appName.trim()||!secteur.trim()?"#e9e9e9":"linear-gradient(135deg,#7c3aed,#4f46e5)",color:!appName.trim()||!secteur.trim()?"#aaa":"white",border:"none",borderRadius:10,fontSize:13,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}}>Générer ✨</button>
      </div>
      {prefill?.sofia&&<div style={{marginTop:10,background:"#f5f3ff",borderRadius:10,padding:"8px 12px",fontSize:11,color:"#5b21b6"}}>✅ Contexte Jordan + Sofia chargé</div>}
    </div>}
    {(phase==="gen"||phase==="done")&&<StepBar steps={S_STEPS} current={step} done={data} loading={loading}/>}
    {phase==="done"&&<div style={{animation:"fadeUp .4s ease-out"}}>
      {data.vision&&!data.vision._err&&<Block title="🎯 Vision Produit" accent="#7c3aed">
        {data.vision.oneliner&&<div style={{background:"linear-gradient(135deg,#faf5ff,#f0f4ff)",borderRadius:10,padding:"10px 13px",marginBottom:8,fontSize:13,fontStyle:"italic",color:"#4c1d95",fontWeight:600}}>"{data.vision.oneliner}"</div>}
        <IB label="Problème profond" bg="#f8f8ff" full>{data.vision.probleme}</IB>
        <G2><LB label="Ce que fait l'app" items={data.vision.fait} color="#15803d" bg="#f0fdf4"/><LB label="Hors périmètre" items={data.vision.pasfait} color="#991b1b" bg="#fff5f5"/></G2>
        <G2><IB label="Users 1" bg="#f8f8ff">{data.vision.user1}</IB><IB label="Users 2" bg="#f8f8ff">{data.vision.user2}</IB></G2>
        <G2><IB label="Risque 1" bg="#fff8f0">{data.vision.risque1}</IB><IB label="Risque 2" bg="#fff8f0">{data.vision.risque2}</IB></G2>
        <div style={{background:"linear-gradient(135deg,#fdf4ff,#f0f4ff)",border:"1px solid #e9d5ff",borderRadius:10,padding:"10px 13px",marginBottom:7}}><div style={{fontSize:8,fontWeight:700,color:"#7c3aed",letterSpacing:1,marginBottom:3,textTransform:"uppercase"}}>Wow feature</div><div style={{fontSize:12,fontWeight:600,color:"#1a1a2e"}}>{data.vision.wow}</div></div>
        <Init label="Initiative Marcus">{data.vision.conseil}</Init>
      </Block>}
      {data.screens&&!data.screens._err&&<Block title="📱 Écrans & UX" accent="#4f46e5">
        <LB label="Onboarding" items={data.screens.onboarding} color="#1d4ed8" bg="#eff6ff"/>
        <LB label="Écrans principaux" items={data.screens.core} color="#5b21b6" bg="#faf5ff"/>
        <G2><IB label="CTA" bg="#f0fdf4">{data.screens.cta}</IB><IB label="Rétention" bg="#fef9c3">{data.screens.retention}</IB></G2>
        <IB label="Anti-pattern UX" bg="#fff8f0" full>{data.screens.antipattern}</IB>
        <Init label="Initiative Marcus">{data.screens.conseil}</Init>
      </Block>}
      {data.logic&&!data.logic._err&&<Block title="⚙️ Logique & Données" accent="#0891b2">
        <LB label="Entités" items={data.logic.entites} color="#0e7490" bg="#ecfeff"/>
        <LB label="Règles métier" items={data.logic.regles} color="#1d4ed8" bg="#eff6ff"/>
        <LB label="Automatisations" items={data.logic.autos} color="#6d28d9" bg="#faf5ff"/>
        {data.logic.apis?.length>0&&<LB label="APIs" items={data.logic.apis} color="#065f46" bg="#f0fdf4"/>}
        <Init label="Initiative Marcus">{data.logic.conseil}</Init>
      </Block>}
      {data.nocode&&!data.nocode._err&&<Block title="🛠️ Architecture No-Code" accent="#059669">
        <G2>{[["Principal",data.nocode.principal],["DB",data.nocode.db],["Auth",data.nocode.auth],["Paiement",data.nocode.paiement],["Notifs",data.nocode.notifs],["IA",data.nocode.ia]].map(([l,v])=><IB key={l} label={l} bg="#f0fdf4">{v||"Non requis"}</IB>)}</G2>
        {data.nocode.workflows?.length>0&&<LB label="Workflows" items={data.nocode.workflows} color="#6d28d9" bg="#faf5ff"/>}
        <G2><IB label="Coût stack" bg="#fef9c3">{data.nocode.cout}</IB><IB label="Temps MVP" bg="#f0fdf4">{data.nocode.mvp}</IB></G2>
        <div style={{background:"#fff8f0",border:"1px solid #fed7aa",borderRadius:10,padding:"10px 12px"}}><div style={{fontSize:8,fontWeight:700,color:"#9a3412",letterSpacing:1,marginBottom:3,textTransform:"uppercase"}}>Piège absolu</div><div style={{fontSize:11,color:"#7c2d12"}}>{data.nocode.piege}</div></div>
      </Block>}
      {data.launch&&!data.launch._err&&<Block title="🚀 Lancement & KPIs" accent="#dc2626">
        <G2><LB label="MVP inclus" items={data.launch.inclus} color="#15803d" bg="#f0fdf4"/><LB label="MVP exclu" items={data.launch.exclu} color="#991b1b" bg="#fff5f5"/></G2>
        <IB label="Valider avant de construire" bg="#f8f8ff" full>{data.launch.validation}</IB>
        <IB label="100 premiers users" bg="#f0f9ff" full>{data.launch.premiers}</IB>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,margin:"8px 0"}}>
          {[["Sem 1",data.launch.s1],["Mois 1",data.launch.m1],["Mois 3",data.launch.m3]].map(([l,v])=><div key={l} style={{background:"#faf5ff",border:"1px solid #e9d5ff",borderRadius:10,padding:"9px 11px",textAlign:"center"}}><div style={{fontSize:8,fontWeight:700,color:"#aaa",letterSpacing:1,marginBottom:3,textTransform:"uppercase"}}>{l}</div><div style={{fontSize:11,fontWeight:700,color:"#5b21b6"}}>{v||"—"}</div></div>)}
        </div>
        <div style={{background:"#fee2e2",border:"1px solid #fca5a5",borderRadius:10,padding:"11px 13px",marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#991b1b",letterSpacing:1,marginBottom:4,textTransform:"uppercase"}}>Action demain 9h</div><div style={{fontSize:12,fontWeight:700,color:"#7f1d1d"}}>{data.launch.demain}</div></div>
        <Conseil label="Conseil Marcus">{data.launch.conseil}</Conseil>
      </Block>}
      <div style={{display:"flex",gap:8,justifyContent:"center",marginTop:12,flexWrap:"wrap"}}>
        <ExportBtn onClick={exportMD} label="Télécharger .md"/>
        <ResetBtn onClick={()=>{setPhase("idle");setData({});}}/>
      </div>
    </div>}
  </div>;
}

// ─── AGENT 4 : LEO (ASO) ───────────────────────────
function AgentASO() {
  const [nom,setNom]=useState(""); const [secteur,setSecteur]=useState(""); const [desc,setDesc]=useState(""); const [cible,setCible]=useState("");
  const [notes,setNotes]=useState("4.2");
  const [phase,setPhase]=useState("idle"); const [data,setData]=useState({}); const [step,setStep]=useState(0); const [loading,setLoading]=useState(false);

  async function run(){
    if(!nom.trim()||!secteur.trim()||loading) return;
    setLoading(true); setData({}); setStep(0); setPhase("gen");
    const full={};
    const steps=[{key:"store",fn:()=>P_ASO_STORE(nom,secteur,desc,cible)},{key:"reviews",fn:()=>P_ASO_NOTES(nom,notes)}];
    for(let i=0;i<steps.length;i++){
      setStep(i);
      try{ full[steps[i].key]=await callClaude(steps[i].fn()); }
      catch(e){ full[steps[i].key]={_err:e.message}; }
      setData({...full});
    }
    setPhase("done"); setLoading(false);
  }

  function exportMD(){
    const d=data; let md="# FICHE ASO — "+nom+"\n\n";
    if(d.store){
      md+="## Fiche Store\n**Titre:** "+d.store.titre+"\n**Sous-titre:** "+d.store.sous_titre+"\n**Description courte:** "+d.store.description_courte+"\n\n**Description longue:**\n"+d.store.description_longue+"\n\n**Keywords:** "+(d.store.keywords||[]).join(", ")+"\n**Catégorie:** "+d.store.categorie+" / "+d.store.categorie2+"\n\n**Screenshots:**\n"+(d.store.screenshots||[]).map((s,i)=>`${i+1}. ${s}`).join("\n")+"\n\n";
      md+="**Conseil Leo:** "+d.store.conseil_leo+"\n\n";
    }
    if(d.reviews) md+="## Stratégie Notes\n- Stratégie: "+d.reviews.strategie_reviews+"\n- Moment: "+d.reviews.moment_demande+"\n- Message: "+d.reviews.message_demande+"\n- Réponse mauvaise note: "+d.reviews.reponse_mauvaise_note+"\n- A/B test: "+d.reviews.a_b_test+"\n- Hack: "+d.reviews.conseil_leo;
    const blob=new Blob([md],{type:"text/markdown"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a"); a.href=url; a.download="ASO_"+nom.replace(/\s+/g,"_")+".md"; a.click(); URL.revokeObjectURL(url);
  }

  return <div>
    <div style={{background:"linear-gradient(135deg,#0891b2,#0e7490)",borderRadius:16,padding:"20px",marginBottom:16}}>
      <div style={{fontSize:28,marginBottom:6}}>📱</div>
      <div style={{fontWeight:900,fontSize:18,color:"white",marginBottom:3}}>Leo — Agent ASO</div>
      <div style={{fontSize:12,color:"rgba(255,255,255,.7)"}}>Ex-Head of Growth Spotify · 200+ fiches optimisées · 3 apps à 1M+ téléchargements</div>
    </div>
    {phase==="idle"&&<div style={{background:"white",borderRadius:14,padding:18,boxShadow:"0 2px 12px rgba(0,0,0,.07)",marginBottom:16}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
        <input value={nom} onChange={e=>setNom(e.target.value)} placeholder="Nom de l'app" style={{border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#0891b2"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <input value={secteur} onChange={e=>setSecteur(e.target.value)} placeholder="Secteur" style={{border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#0891b2"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <input value={cible} onChange={e=>setCible(e.target.value)} placeholder="Cible (ex: freelances 25-35)" style={{border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#0891b2"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Note actuelle (ex: 4.2)" style={{border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#0891b2"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
      </div>
      <textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Description de l'app (optionnel — ce qu'elle fait)" style={{width:"100%",border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit",resize:"vertical",minHeight:60,marginBottom:8}} onFocus={e=>e.target.style.borderColor="#0891b2"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
      <button onClick={run} disabled={loading||!nom.trim()||!secteur.trim()} style={{width:"100%",padding:"12px",background:!nom.trim()||!secteur.trim()?"#e9e9e9":"linear-gradient(135deg,#0891b2,#0e7490)",color:!nom.trim()||!secteur.trim()?"#aaa":"white",border:"none",borderRadius:10,fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>Optimiser la fiche store ✨</button>
    </div>}
    {(phase==="gen"||phase==="done")&&<StepBar steps={A_STEPS} current={step} done={data} loading={loading}/>}
    {phase==="done"&&<div style={{animation:"fadeUp .4s ease-out"}}>
      {data.store&&!data.store._err&&<Block title="📱 Fiche App Store / Play Store" accent="#0891b2">
        <div style={{background:"linear-gradient(135deg,#ecfeff,#f0f9ff)",borderRadius:12,padding:"14px 16px",marginBottom:10}}>
          <div style={{fontWeight:900,fontSize:16,color:"#0e7490",marginBottom:3}}>{data.store.titre}</div>
          <div style={{fontSize:13,color:"#0891b2",marginBottom:8}}>{data.store.sous_titre}</div>
          <div style={{background:"#fef9c3",borderRadius:8,padding:"8px 10px",fontSize:12,color:"#92400e",fontWeight:600,marginBottom:6}}>{data.store.description_courte}</div>
          <div style={{fontSize:11,color:"#555",lineHeight:"1.6"}}>{data.store.description_longue}</div>
        </div>
        <div style={{marginBottom:10}}><div style={{fontSize:8,fontWeight:700,color:"#aaa",letterSpacing:1,marginBottom:6,textTransform:"uppercase"}}>Keywords</div><div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{(data.store.keywords||[]).map((k,i)=><span key={i} style={{background:"#ecfeff",color:"#0e7490",borderRadius:6,padding:"3px 9px",fontSize:11,fontWeight:600}}>{k}</span>)}</div></div>
        <G2><IB label="Catégorie 1" bg="#ecfeff">{data.store.categorie}</IB><IB label="Catégorie 2" bg="#ecfeff">{data.store.categorie2}</IB></G2>
        <LB label="Descriptions screenshots" items={data.store.screenshots} color="#0891b2" bg="#f0f9ff"/>
        <Init label="Conseil Leo" color="#0891b2">{data.store.conseil_leo}</Init>
      </Block>}
      {data.reviews&&!data.reviews._err&&<Block title="⭐ Stratégie Notes & Reviews" accent="#0e7490">
        <IB label="Stratégie reviews" bg="#ecfeff" full>{data.reviews.strategie_reviews}</IB>
        <G2><IB label="Quand demander" bg="#f0fdf4">{data.reviews.moment_demande}</IB><IB label="A/B test prioritaire" bg="#fef9c3">{data.reviews.a_b_test}</IB></G2>
        <div style={{background:"#f0f9ff",borderRadius:10,padding:"11px 13px",marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#0891b2",letterSpacing:1,marginBottom:5,textTransform:"uppercase"}}>Message exact à afficher</div><div style={{fontSize:12,color:"#0e7490",fontStyle:"italic"}}>"{data.reviews.message_demande}"</div></div>
        <IB label="Réponse aux 1-2 étoiles" bg="#fff5f5" full>{data.reviews.reponse_mauvaise_note}</IB>
        <Init label="Hack ASO de Leo" color="#0891b2">{data.reviews.conseil_leo}</Init>
      </Block>}
      <div style={{display:"flex",gap:8,justifyContent:"center",marginTop:12,flexWrap:"wrap"}}>
        <ExportBtn onClick={exportMD} label="Télécharger .md" c1="#0891b2" c2="#0e7490"/>
        <ResetBtn onClick={()=>{setPhase("idle");setData({});}}/>
      </div>
    </div>}
  </div>;
}

// ─── AGENT 5 : MAYA (MARKETING) ────────────────────
function AgentMarketing() {
  const [nom,setNom]=useState(""); const [secteur,setSecteur]=useState(""); const [cible,setCible]=useState("");
  const [phase,setPhase]=useState("idle"); const [data,setData]=useState({}); const [step,setStep]=useState(0); const [loading,setLoading]=useState(false);

  async function run(){
    if(!nom.trim()||!secteur.trim()||loading) return;
    setLoading(true); setData({}); setStep(0); setPhase("gen");
    const full={};
    const steps=[{key:"strategy",fn:()=>P_CONTENT_STRATEGY(nom,secteur,cible)},{key:"posts",fn:()=>P_POSTS(nom,secteur,cible)},{key:"calendar",fn:()=>P_CALENDAR(nom,secteur)}];
    for(let i=0;i<steps.length;i++){
      setStep(i);
      try{ full[steps[i].key]=await callClaude(steps[i].fn()); }
      catch(e){ full[steps[i].key]={_err:e.message}; }
      setData({...full});
    }
    setPhase("done"); setLoading(false);
  }

  function exportMD(){
    const d=data; let md="# MARKETING — "+nom+"\n\n";
    if(d.strategy) md+="## Stratégie\n- Positionnement: "+d.strategy.positionnement+"\n- Ton: "+d.strategy.ton+"\n- Canaux: "+d.strategy.canal1+" / "+d.strategy.canal2+" / "+d.strategy.canal3+"\n- Pilliers: "+d.strategy.contenu_pilier1+" | "+d.strategy.contenu_pilier2+" | "+d.strategy.contenu_pilier3+"\n- Conseil: "+d.strategy.conseil_maya+"\n\n";
    if(d.posts){
      ["post1","post2","post3"].forEach((k,i)=>{
        const p=d.posts[k]; if(!p) return;
        md+="## Post LinkedIn "+(i+1)+"\nHook: "+p.hook+"\n\n"+p.corps+"\n\nCTA: "+p.cta+"\n"+(p.hashtags||[]).map(h=>"#"+h).join(" ")+"\n\n";
      });
    }
    if(d.calendar) md+="## Calendrier 4 semaines\n"+(["s1","s2","s3","s4"]).map((k,i)=>"Semaine "+(i+1)+":\n"+(d.calendar[k]||[]).join("\n")).join("\n\n");
    const blob=new Blob([md],{type:"text/markdown"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a"); a.href=url; a.download="MARKETING_"+nom.replace(/\s+/g,"_")+".md"; a.click(); URL.revokeObjectURL(url);
  }

  return <div>
    <div style={{background:"linear-gradient(135deg,#ea580c,#dc2626)",borderRadius:16,padding:"20px",marginBottom:16}}>
      <div style={{fontSize:28,marginBottom:6}}>📣</div>
      <div style={{fontWeight:900,fontSize:18,color:"white",marginBottom:3}}>Maya — Agent Marketing</div>
      <div style={{fontSize:12,color:"rgba(255,255,255,.7)"}}>Ex-CMO licorne SaaS · Exit $400M · 50+ campagnes virales · Posts à 100k vues</div>
    </div>
    {phase==="idle"&&<div style={{background:"white",borderRadius:14,padding:18,boxShadow:"0 2px 12px rgba(0,0,0,.07)",marginBottom:16}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
        <input value={nom} onChange={e=>setNom(e.target.value)} placeholder="Nom de l'app" style={{border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#ea580c"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
        <input value={secteur} onChange={e=>setSecteur(e.target.value)} placeholder="Secteur" style={{border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#ea580c"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
      </div>
      <input value={cible} onChange={e=>setCible(e.target.value)} onKeyDown={e=>e.key==="Enter"&&run()} placeholder="Cible (ex: entrepreneurs 25-40 ans)" style={{width:"100%",border:"2px solid #f0f0f0",borderRadius:10,padding:"11px 14px",fontSize:13,outline:"none",fontFamily:"inherit",marginBottom:8}} onFocus={e=>e.target.style.borderColor="#ea580c"} onBlur={e=>e.target.style.borderColor="#f0f0f0"}/>
      <button onClick={run} disabled={loading||!nom.trim()||!secteur.trim()} style={{width:"100%",padding:"12px",background:!nom.trim()||!secteur.trim()?"#e9e9e9":"linear-gradient(135deg,#ea580c,#dc2626)",color:!nom.trim()||!secteur.trim()?"#aaa":"white",border:"none",borderRadius:10,fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>Générer le plan marketing ✨</button>
    </div>}
    {(phase==="gen"||phase==="done")&&<StepBar steps={M_STEPS} current={step} done={data} loading={loading}/>}
    {phase==="done"&&<div style={{animation:"fadeUp .4s ease-out"}}>
      {data.strategy&&!data.strategy._err&&<Block title="🎯 Stratégie de contenu" accent="#ea580c">
        <G2><IB label="Positionnement" bg="#fff7ed">{data.strategy.positionnement}</IB><IB label="Ton" bg="#fff7ed">{data.strategy.ton}</IB></G2>
        <div style={{marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#aaa",letterSpacing:1,marginBottom:6,textTransform:"uppercase"}}>Canaux</div><div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{[data.strategy.canal1,data.strategy.canal2,data.strategy.canal3].filter(Boolean).map((c,i)=><span key={i} style={{background:"#fff7ed",border:"1px solid #fed7aa",borderRadius:8,padding:"4px 10px",fontSize:11,color:"#92400e",fontWeight:500}}>{c}</span>)}</div></div>
        <div style={{marginBottom:8}}><div style={{fontSize:8,fontWeight:700,color:"#aaa",letterSpacing:1,marginBottom:6,textTransform:"uppercase"}}>Pilliers de contenu</div><div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{[data.strategy.contenu_pilier1,data.strategy.contenu_pilier2,data.strategy.contenu_pilier3].filter(Boolean).map((p,i)=><span key={i} style={{background:"#fef3c7",border:"1px solid #fde68a",borderRadius:8,padding:"4px 10px",fontSize:11,color:"#92400e",fontWeight:500}}>{p}</span>)}</div></div>
        {data.strategy.hook_types?.length>0&&<LB label="Types de hooks" items={data.strategy.hook_types} color="#ea580c" bg="#fff7ed"/>}
        <Init label="Insight Maya" color="#ea580c">{data.strategy.conseil_maya}</Init>
      </Block>}
      {data.posts&&!data.posts._err&&<Block title="✍️ 3 Posts LinkedIn prêts à publier" accent="#dc2626">
        <PostCard post={data.posts.post1} i={0} accent="#667eea"/>
        <PostCard post={data.posts.post2} i={1} accent="#f093fb"/>
        <PostCard post={data.posts.post3} i={2} accent="#4facfe"/>
        {data.posts.conseil_maya&&<Init label="Ce qui rend viral selon Maya" color="#ea580c">{data.posts.conseil_maya}</Init>}
      </Block>}
      {data.calendar&&!data.calendar._err&&<Block title="📅 Calendrier éditorial — 4 semaines" accent="#ea580c">
        {["s1","s2","s3","s4"].map((k,i)=><div key={k} style={{marginBottom:10}}>
          <div style={{fontSize:11,fontWeight:700,color:"#ea580c",marginBottom:6}}>Semaine {i+1}</div>
          {(data.calendar[k]||[]).map((j,ji)=><div key={ji} style={{background:"#fff7ed",borderRadius:8,padding:"7px 10px",marginBottom:4,fontSize:11,color:"#444"}}>{j}</div>)}
        </div>)}
        <G2><IB label="Format gagnant" bg="#fff7ed">{data.calendar.format_gagnant}</IB><IB label="Timing optimal" bg="#fef9c3">{data.calendar.conseil_maya}</IB></G2>
      </Block>}
      <div style={{display:"flex",gap:8,justifyContent:"center",marginTop:12,flexWrap:"wrap"}}>
        <ExportBtn onClick={exportMD} label="Télécharger .md" c1="#ea580c" c2="#dc2626"/>
        <ResetBtn onClick={()=>{setPhase("idle");setData({});}}/>
      </div>
    </div>}
  </div>;
}

// ─── DASHBOARD ─────────────────────────────────────
const AGENTS=[
  {id:"ideation",label:"Jordan",emoji:"🔍",color:"#667eea"},
  {id:"rapport", label:"Sofia", emoji:"📊",color:"#f093fb"},
  {id:"specs",   label:"Marcus",emoji:"📋",color:"#7c3aed"},
  {id:"aso",     label:"Leo",   emoji:"📱",color:"#0891b2"},
  {id:"marketing",label:"Maya", emoji:"📣",color:"#ea580c"},
];

export default function Dashboard() {
  const [active,setActive]=useState("ideation");
  const [prefill,setPrefill]=useState(null);
  const [ctx,setCtx]=useState({});

  function handleSelectApp(app,secteur){
    const c={nom:app.nom,secteur,emoji:app.emoji,jordan:{gap:app.gap,ia_advantage:app.ia_advantage||app.ia_avantage,outil_nocode:app.outil,cout_infra:app.infra,clients_pour_rentable:app.clients,prix_client:app.prix,initiative:app.conseil,tagline:app.tagline}};
    setCtx(c); setPrefill(c); setActive("rapport");
  }
  function goToSpecs(sofiaData){
    const c={...ctx,sofia:{marche:sofiaData.marche||null,business:sofiaData.business||null,roadmap:sofiaData.roadmap||null,gtm:sofiaData.gtm||null}};
    setCtx(c); setPrefill(c); setActive("specs");
  }

  return <div style={{minHeight:"100vh",background:"#f5f6fa",fontFamily:"Inter,-apple-system,sans-serif",display:"flex",flexDirection:"column"}}>
    <div style={{background:"white",borderBottom:"1px solid #f0f0f0",padding:"10px 16px",display:"flex",alignItems:"center",gap:"10px",boxShadow:"0 1px 4px rgba(0,0,0,.06)",position:"sticky",top:0,zIndex:50,flexWrap:"wrap"}}>
      <div style={{width:30,height:30,borderRadius:8,background:"linear-gradient(135deg,#667eea,#7c3aed)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>⚡</div>
      <div style={{flexShrink:0}}><div style={{fontWeight:900,fontSize:13,color:"#1a1a2e",lineHeight:1.2}}>APEX Studio</div><div style={{fontSize:9,color:"#aaa"}}>5 AGENTS · POWERED BY CLAUDE</div></div>
      <div style={{display:"flex",gap:5,marginLeft:"auto",flexWrap:"wrap"}}>
        {AGENTS.map(a=><button key={a.id} onClick={()=>setActive(a.id)} style={{padding:"5px 12px",background:active===a.id?a.color:"transparent",color:active===a.id?"white":"#666",border:"1px solid "+(active===a.id?a.color:"#e8e8f0"),borderRadius:20,fontSize:11,fontWeight:active===a.id?700:400,cursor:"pointer",fontFamily:"inherit",transition:"all .15s",whiteSpace:"nowrap"}}>
          {a.emoji} {a.label}
        </button>)}
      </div>
    </div>
    <div style={{flex:1,maxWidth:880,width:"100%",margin:"0 auto",padding:"22px 14px 60px"}}>
      {active==="ideation" && <AgentIdeation onSelectApp={handleSelectApp}/>}
      {active==="rapport"  && <AgentRapport  key={prefill?.nom||"r"} prefill={prefill} onGoToSpecs={goToSpecs}/>}
      {active==="specs"    && <AgentSpecs    key={(prefill?.nom||"s")+(prefill?.sofia?"s":"")} prefill={prefill}/>}
      {active==="aso"      && <AgentASO/>}
      {active==="marketing"&& <AgentMarketing/>}
    </div>
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}*{box-sizing:border-box}`}</style>
  </div>;
}
