# 🚀 APEX Studio — Guide de déploiement Vercel

## Ce que tu as dans ce dossier

```
apex-studio/
├── src/App.jsx          ← Tout le code des 5 agents IA
├── src/main.jsx         ← Point d'entrée React
├── api/claude.js        ← Proxy sécurisé (ta clé API reste cachée)
├── index.html           ← Page HTML
├── package.json         ← Dépendances
├── vite.config.js       ← Config Vite
└── vercel.json          ← Config Vercel
```

---

## 📋 Étapes de déploiement (15 min)

### 1. Créer un compte GitHub
→ https://github.com/signup (gratuit)

### 2. Créer un nouveau repo
- Clique sur **"+"** en haut à droite → **"New repository"**
- Nom : `apex-studio`
- **Public** ou **Private** (les deux marchent)
- Clique **"Create repository"**

### 3. Uploader les fichiers
- Sur la page du repo, clique **"uploading an existing file"**
- Glisse-dépose **tout le dossier apex-studio**
- Clique **"Commit changes"**

### 4. Créer un compte Vercel
→ https://vercel.com/signup
- Connecte-toi avec ton compte **GitHub** (c'est le plus simple)

### 5. Importer le projet
- Sur Vercel, clique **"Add New → Project"**
- Sélectionne ton repo `apex-studio`
- Clique **"Deploy"** (Vercel détecte automatiquement que c'est un projet Vite/React)

### 6. Ajouter ta clé API Anthropic (IMPORTANT)
- Va sur https://console.anthropic.com → **"API Keys"** → **"Create Key"**
- Copie la clé (commence par `sk-ant-...`)
- Sur Vercel → ton projet → **"Settings"** → **"Environment Variables"**
- Ajoute :
  - **Name** : `ANTHROPIC_API_KEY`
  - **Value** : ta clé `sk-ant-...`
- Clique **"Save"**
- Va dans **"Deployments"** → clique les **3 points** sur le dernier déploiement → **"Redeploy"**

### 7. C'est en ligne ! 🎉
- Vercel te donne une URL type `apex-studio-xxx.vercel.app`
- Accessible depuis n'importe quel navigateur, n'importe où
- Les données sont sauvegardées dans ton navigateur (localStorage)

---

## 💡 Notes importantes

- **Coût API** : chaque analyse coûte ~0,01-0,05€. Mets une limite de crédit sur console.anthropic.com
- **Mises à jour** : modifie les fichiers sur GitHub → Vercel redéploie automatiquement
- **Domaine custom** : sur Vercel tu peux brancher ton propre domaine (apex.tonsite.com)

